package pe.edu.upeu.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoTddApplicationTests {

	@Test
	void contextLoads() {
	}

}
